#Write a python program to store marks stored in subject "Fundamentals of Data Structure" by N students in the class. Write functions to compute following:
    #                     1. The average score of the class.
    #                     2. Highest score and lowest score of the class.
    #                     3. Count of students who were absent for the test.
    #                     4. Display mark with highest frequency.
marks=[]
def get_marks():
    n = int(input("enter the no. of students"))
    for i in range(n):
        m=int(input("Enter the  marks(-1 one absent students)"))
        marks.append(m)
    
    print(marks)
def avg():
    sum=0
    cunt=0
    for i in range(len(marks) ):
        sum=sum+marks[i]
        cunt+=1
    print(" sum =" ,sum)
    print("average = ",sum//cunt)
def low_high():
    temp=marks[0]
    for i in range(len(marks)):
        if temp<marks[i]:
            temp=marks[i]
    print("the highest marks = ",temp)

    for i in range(len(marks)):
        if temp>marks[i]:
            temp=marks[i]
    print("the lowest marks is = " ,temp)

def absent():
    absent=0
    for i in range(len(marks)):
        if marks==-1:
            absent+=1
    print(" no .absent is = ", absent)
def high_fre():
   temp=marks[0]
   for i in range(len(marks)):
     if temp < marks(i):
        temp=marks(i)
     print("high frequecny is = ",temp )
get_marks()
while True:
    print(" 1 for average ")
    print(" 2 for highest lowest ")
    print(" 3 for absent student ")
    print(" 4 for high frequency ")
    print(" 5 for exit ")
    ch=int(input("Enter The choice"))
    if ch==1:
        avg()
    if ch==2:
        low_high()
    if ch==3:
        absent()
    if ch==4:
        high_fre()
    if ch==5:
        exit()




